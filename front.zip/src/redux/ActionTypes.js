export const POST_USER = 'POST_USER';
export const USERS_LOADING = 'USERS_LOADING';
export const ADD_USERS = 'ADD_USERS';
export const USERS_FAILED = 'USERS_FAILED';
export const ADD_USER = 'ADD_USER';
export const MODIFY_USER = 'MODIFY_USER';
export const DELETE_USER = 'DELETE_USER';